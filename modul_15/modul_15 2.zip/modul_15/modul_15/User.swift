//
//  User.swift
//  modul_15
//
//  Created by Admin on 17/04/24.
//

import Foundation
import UIKit

struct User {
    let name: String
    let lastName: String
    let age: String
    let avatarImage: UIImage?
}
