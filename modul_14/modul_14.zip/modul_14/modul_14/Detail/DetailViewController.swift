//
//  DetailViewController.swift
//  modul_14
//
//  Created by Admin on 06/04/24.
//

import UIKit

class DetailViewController: UIViewController {

    
    @IBOutlet weak var nameLabel: UILabel! {
        didSet {
            nameLabel.text = info?.name
        }
    }
    
    var info: UserInfo?
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }
    


}
